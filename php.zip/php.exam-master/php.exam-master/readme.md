## Run the following commands
- php artisan migrate
- php artisan db:seed